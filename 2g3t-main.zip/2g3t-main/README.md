# DUPLA
## Macson - 24 --- Arthur - 1.
